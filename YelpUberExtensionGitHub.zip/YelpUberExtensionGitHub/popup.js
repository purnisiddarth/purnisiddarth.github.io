// Uber API Constants
var uberClientId = "YOUR_CLIENT_ID"
	, uberServerToken = "YOUR_SERVER_TOKEN"
    , redirect_uri = "YOUR_REDIRECT_URI";

// Create variables to store latitude and longitude
var startLatitude
  , startLongitude
  , endLatitude
  , endLongitude;

window.onload = loadButton;

//Load the uber button with the time estimate
function loadButton() {
    //Get the address using existing chrome extension      
    var address = chrome.extension.getBackgroundPage().selectedAddress;
    if (address) {
        //Call google api to get latitude and longitude of given address
        gclient_geocode(address);
    }
}

//Uses the address from the yelp page and calls google api to get the destination latitude and longitude
function gclient_geocode(address) {
    var url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' +
            encodeURIComponent(address) + '&sensor=false';
    var request = new XMLHttpRequest();
    
    request.open('GET', url, true);
    console.log(url);
    request.onreadystatechange = function (e) {
        console.log(request, e);
        if (request.readyState == 4) {
            if (request.status == 200) {
                var json = JSON.parse(request.responseText);
                //Get latitude and longitude from json
                var latlng = json.results[0].geometry.location;

                //Set variables with latitude and longitude
                endLatitude = latlng.lat;
                endLongitude = latlng.lng;

                //Call geolocation to get latitude and longitude of origin
                navigator.geolocation.watchPosition(showPosition);

            } else {
                console.log('Unable to resolve address into lat/lng');
            }
        }
    };
    request.send(null);
}

//Get origin latitude and longitude from geoLocation
function showPosition(position) {
    // Query Uber API 
    getEstimatesForUserLocation(position.coords.latitude, position.coords.longitude);
}

//Calls uber api price endpoint with origin and destination latitude and longitude to compute the minimum time it will take for user to get a ride
function getEstimatesForUserLocation(latitude, longitude) {
    $.ajax({
        url: "https://api.uber.com/v1/estimates/price",
        headers: {
            Authorization: "Token " + uberServerToken
        },
        data: {
            start_latitude: latitude,
            start_longitude: longitude,
            end_latitude: endLatitude,
            end_longitude: endLongitude
        },
        success: function (result) {
            console.log(JSON.stringify(result));

            // 'results' is an object with a key containing an Array
            var data = result["prices"];
            if (typeof data != typeof undefined) {
                // Sort Uber products by time to the user's location 
                data.sort(function (t0, t1) {
                    return t0.duration - t1.duration;
                });

                // Update the Uber button with the shortest time
                var shortest = data[0];
                if (typeof shortest != typeof undefined) {
                    console.log("Updating time estimate...");
                    $("#time").html("IN " + Math.ceil(shortest.duration / 60.0) + " MIN");
                }
            }
        },
        error: function (error) {
            //Log error
            console.log("ERROR: ", error);
        }
    });
}

$("a").click(function (event) {
    // Redirect to Uber API - Login and redirect to app page
    var uberURL = "https://login.uber.com/oauth/authorize?client_id=" + uberClientId + "&response_type=code&scope=profile%20request&redirect_uri=";
    //Localhost
    //uberURL += encodeURIComponent("http://localhost:8080");

    //Publicly accessible URL
    uberURL += encodeURIComponent(redirect_uri);

    var request = new XMLHttpRequest();

    request.open('POST', uberURL, true);
    console.log(uberURL);
    request.onreadystatechange = function (e) {
        console.log(request, e);
        if (request.readyState == 4) {
            if (request.status == 200) {
                var json = JSON.parse(request.responseText);
                alert(json.results[0]);

            } else {
                console.log('Unable to login');
            }
        }
    };
    request.send(null);
    // Redirect to Uber
    parent.window.open(uberURL, "Uber Login");
    
});